#!/bin/bash

yarn debug:php:stop