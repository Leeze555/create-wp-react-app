#!/bin/bash

yarn debug:php:start