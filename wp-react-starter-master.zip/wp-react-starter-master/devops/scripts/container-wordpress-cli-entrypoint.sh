#!/bin/sh

# Copy the installed WP-CLI binary so it can be used through the wordpress environment

cp /usr/local/bin/wp /var/www/html/