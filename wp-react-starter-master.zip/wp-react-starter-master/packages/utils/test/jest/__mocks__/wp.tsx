/* eslint-disable import/no-default-export */
export default {
    i18n: {
        setLocaleData: jest.fn()
    }
};
