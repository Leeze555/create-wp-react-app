// @see https://github.com/microsoft/TypeScript/issues/15031#issuecomment-407131785
declare module "*";
