/* eslint-disable import/no-default-export */
import { createDefaultSettings } from "../../../common/webpack.factory";

export default createDefaultSettings("package");
