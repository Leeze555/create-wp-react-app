#!/bin/bash

# Run your commands for startup of WordPress for this specific plugin in the main docker environment.

PLUGIN_SLUG="wp-reactjs-starter"
echo "Initiate $PLUGIN_SLUG..."