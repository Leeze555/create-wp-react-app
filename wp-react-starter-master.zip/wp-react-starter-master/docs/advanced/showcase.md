# Showcase

Who is using this boilerplate? That's a valid question!

-   [WP Real Media Library](https://matthias-web.com/go/codecanyon/13155134)
-   [WP Real Physical Media](https://matthias-web.com/go/codecanyon/23104206)
-   [WP Real Thumbnail Generator](https://matthias-web.com/go/codecanyon/18937507)
-   [WP Real Categories Management](https://matthias-web.com/go/codecanyon/13580393)

{% hint style="info" %}
You are using it? Let us know and we will add your plugin to the list! Just contribute to that file or contact us directly.
{% endhint %}
